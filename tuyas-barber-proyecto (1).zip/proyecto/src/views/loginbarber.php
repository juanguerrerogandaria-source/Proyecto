<?php
require_once __DIR__ . '/../../database/db.php';
require_once __DIR__ . '/../../includes/auth.php';

$message = "";
$success = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $usuario  = trim($_POST["usuario"] ?? "");
    $password = trim($_POST["password"] ?? "");

    if (empty($usuario) || empty($password)) {
        $message = "Por favor completá todos los campos.";
    } else {
        try {
            $fila = find_user_by_username($usuario);

            if ($fila === null) {
                $message = "Usuario no encontrado.";
            } elseif (password_verify($password, $fila["password"])) {
                iniciar_sesion_usuario((int) $fila["id"], $usuario, $fila["role"]);

                header('Location: ' . url_destino_segun_rol($fila["role"]));
                exit;
            } else {
                $message = "Contraseña incorrecta.";
            }
        } catch (RuntimeException $e) {
            $message = $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../public/css/loginbarber.css">
    <title>Login - Tuya's Barber</title>
</head>
<body>
    <div class="sparkles" id="sparkles"></div>

    <div class="auth-wrapper">
        <div class="auth-brand">
            <img src="../../public/img/tuyasbarber.jpeg" alt="Tuya's Barber">
            <h1>Tuya's <span>Barber</span></h1>
            <p>Iniciá sesión y volvé a sentirte como en casa. Tu turno te está esperando.</p>
        </div>

        <form action="loginbarber.php" method="post">
            <h2>Iniciar <span>sesión</span></h2>

            <?php if ($message): ?>
                <p style="color: <?php echo $success ? '#4ade80' : '#f87171'; ?>; text-align:center; margin-bottom: 6px;"><?php echo htmlspecialchars($message); ?></p>
            <?php endif; ?>

            <label for="usuario">Usuario:</label>
            <input type="text" id="usuario" name="usuario" placeholder="Tu usuario" required>

            <label for="password">Contraseña:</label>
            <input type="password" id="password" name="password" placeholder="Tu contraseña" required minlength="6">

            <button type="submit">Verificar</button>

            <a href="registrarse.php">¿No tenés cuenta? Registrate</a>
        </form>
    </div>

    <script>
        const container = document.getElementById('sparkles');
        const total = 45;
        for (let i = 0; i < total; i++) {
            const s = document.createElement('div');
            s.className = 'sparkle';
            s.style.left = Math.random() * 100 + '%';
            s.style.top = Math.random() * 100 + '%';
            s.style.animationDelay = (Math.random() * 3) + 's';
            s.style.animationDuration = (2 + Math.random() * 3) + 's';
            container.appendChild(s);
        }
    </script>
</body>
</html>
