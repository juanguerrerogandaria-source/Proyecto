<?php
require_once __DIR__ . '/../../database/db.php';

$messages = [];
$success = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $usuario          = trim($_POST["usuario"] ?? "");
    $email            = trim($_POST["email"] ?? "");
    $password         = trim($_POST["password"] ?? "");
    $confirm_password = trim($_POST["confirm_password"] ?? "");

    // El registro público SIEMPRE crea usuarios normales.
    // 'admin' y 'super_admin' solo se otorgan desde el panel privado de super_admin.
    $role = "user";

    if (empty($usuario) || empty($email) || empty($password) || empty($confirm_password)) {
        $messages[] = "Todos los campos son obligatorios.";
    }

    if (strlen($password) < 6) {
        $messages[] = "La contraseña debe tener al menos 6 caracteres.";
    }

    if (!preg_match('/[A-Z]/', $password)) {
        $messages[] = "La contraseña debe tener al menos una letra mayúscula.";
    }

    if (!preg_match('/[a-z]/', $password)) {
        $messages[] = "La contraseña debe tener al menos una letra minúscula.";
    }

    if (!preg_match('/[0-9]/', $password)) {
        $messages[] = "La contraseña debe tener al menos un número.";
    }

    if (!preg_match('/[^a-zA-Z0-9]/', $password)) {
        $messages[] = "La contraseña debe tener al menos un carácter especial.";
    }

    if ($password !== $confirm_password) {
        $messages[] = "Las contraseñas no coinciden.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $messages[] = "El correo electrónico no es válido.";
    }

    if (empty($messages)) {
        try {
            $password_hash = password_hash($confirm_password, PASSWORD_DEFAULT);

            if (create_user($usuario, $email, $password_hash, $role)) {
                $success = true;
                $messages[] = "Usuario registrado correctamente.";
            } else {
                $messages[] = "Error al registrar el usuario.";
            }
        } catch (RuntimeException $e) {
            $messages[] = $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../public/css/registrarse.css">
    <title>Registrarse - Tuya's Barber</title>
</head>
<body>
    <div class="sparkles" id="sparkles"></div>

    <div class="auth-wrapper">
        <div class="auth-brand">
            <img src="../../public/img/tuyasbarber.jpeg" alt="Tuya's Barber">
            <h1>Tuya's <span>Barber</span></h1>
            <p>Creá tu cuenta en un minuto y empezá a reservar tus turnos cuando quieras.</p>
        </div>

        <form action="registrarse.php" method="post">
            <h2>Creá tu <span>cuenta</span></h2>

            <?php if (!empty($messages)): ?>
                <div style="text-align:center;">
                    <?php foreach ($messages as $message): ?>
                        <p style="color: <?php echo $success ? '#4ade80' : '#f87171'; ?>; margin: 0.2rem 0; font-size: 14px;">
                            <?php echo htmlspecialchars($message); ?>
                        </p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <label for="usuario">Usuario:</label>
            <input type="text" id="usuario" name="usuario" placeholder="Tu usuario" required>

            <label for="email">Correo Electrónico:</label>
            <input type="email" id="email" name="email" placeholder="correo@ejemplo.com" required>

            <label for="password">Contraseña:</label>
            <input type="password" id="password" name="password" placeholder="Mínimo 6 caracteres" required minlength="6">

            <label for="confirm_password">Confirmar Contraseña:</label>
            <input type="password" id="confirm_password" name="confirm_password" placeholder="Repetí tu contraseña" required minlength="6">

            <button type="submit">Registrarse</button>

            <a href="loginbarber.php">¿Ya tenés cuenta? Iniciar sesión</a>
        </form>
    </div>

    <script>
        const container = document.getElementById('sparkles');
        const total = 45;
        for (let i = 0; i < total; i++) {
            const s = document.createElement('div');
            s.className = 'sparkle';
            s.style.left = Math.random() * 100 + '%';
            s.style.top = Math.random() * 100 + '%';
            s.style.animationDelay = (Math.random() * 3) + 's';
            s.style.animationDuration = (2 + Math.random() * 3) + 's';
            container.appendChild(s);
        }
    </script>
</body>
</html>
